<template>
  <div>
    <h1>This page is protected by auth</h1>
  </div>
</template>
